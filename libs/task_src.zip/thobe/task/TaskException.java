/*
 *  Copyright (C) 2013, Thomas Obenaus. All rights reserved.
 *  Licensed under the New BSD License (3-clause lic).
 *  See attached license-file.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		obenaus.thomas@gmail.com
 *  Project:    JavaComponents/Task
 */
package thobe.task;

/**
 * Class representing an exception thrown by a Task
 * @author Thomas Obenaus
 * @source ExternalProcessExecption.java
 * @date 26 Aug 2008
 */
@SuppressWarnings ( "serial")
public class TaskException extends Exception
{
	private String	details;

	public TaskException( )
	{
		this.details = "";
	}

	public TaskException( String message, String details )
	{
		super( message );
		this.details = details;
	}

	public TaskException( String message, Throwable cause )
	{
		super( message, cause );
		this.details = "";
	}

	public TaskException( Throwable cause )
	{
		super( cause );
		this.details = "";
	}

	public String getDetails( )
	{
		return this.details;
	}
}
