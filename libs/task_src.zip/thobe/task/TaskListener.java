/*
 *  Copyright (C) 2013, Thomas Obenaus. All rights reserved.
 *  Licensed under the New BSD License (3-clause lic).
 *  See attached license-file.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		obenaus.thomas@gmail.com
 *  Project:    JavaComponents/Task
 */
package thobe.task;

/**
 * Interface for a listener which can be used to catch task-events like TASK-DONE, TASK-CANCELED, TASK-STARTED and TASK-PROGRESS-UPDATE:
 * @author Thomas Obenaus
 * @source TaskListener.java
 * @date 27 Jun 2008
 */
public interface TaskListener
{
	/**
	 * Called whenever a task was completed.
	 */
	public void taskDone( Task task );

	/**
	 * Called whenever a task was started.
	 */
	public void taskStarted( Task task );

	/**
	 * Called whenever the Task was canceled/ killed.
	 * @param task
	 */
	public void taskCancelled( Task task );

	/**
	 * Event fired inside the Task. This information is used to be able to send informations about the tasks current working-progress.
	 * @param progressInfo
	 */
	public void progressUpdate( ProgressInformation progressInfo );
}
