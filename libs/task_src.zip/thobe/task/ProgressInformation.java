/*
 *  Copyright (C) 2013, Thomas Obenaus. All rights reserved.
 *  Licensed under the New BSD License (3-clause lic).
 *  See attached license-file.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		obenaus.thomas@gmail.com
 *  Project:    JavaComponents/Task
 */
package thobe.task;

/**
 * Structure to hold informations about the progress of one Task
 * @author Thomas Obenaus
 * @source ProgressInformation.java
 * @date 7 Oct 2008
 */
public class ProgressInformation
{
	/**
	 * Name of the next Task that will be started.
	 */
	private String	nameOfNextTask;

	/**
	 * The currently valid progress.
	 */
	private int		progress;

	/**
	 * Ctor
	 * @param nameOfNextTask
	 * @param progress
	 */
	public ProgressInformation( String nameOfNextTask, int progress )
	{
		this.nameOfNextTask = nameOfNextTask;
		this.progress = progress;
	}

	/**
	 * Returns the currently valid progress.
	 * @return
	 */
	public int getProgress( )
	{
		return this.progress;
	}

	/**
	 * Returns the name of the next Task that will be started.
	 * @return
	 */
	public String getNameOfNextTask( )
	{
		return this.nameOfNextTask;
	}
}
