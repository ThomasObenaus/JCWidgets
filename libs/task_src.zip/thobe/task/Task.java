/*
 *  Copyright (C) 2013, Thomas Obenaus. All rights reserved.
 *  Licensed under the New BSD License (3-clause lic).
 *  See attached license-file.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		obenaus.thomas@gmail.com
 *  Project:    JavaComponents/Task
 */
package thobe.task;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.SwingWorker;

/**
 * Class representing one task. The task will be executed in background. Therefore a SwingWorker will be used to create a new Thread.
 * @author Thomas Obenaus
 * @source Task.java
 * @date 27 Jun 2008
 */
public abstract class Task extends SwingWorker<Void, Void>
{
	/**
	 * The attached task-listeners
	 */
	private ArrayList<TaskListener>	listeners;

	/**
	 * The most recently exception occurred.
	 */
	private TaskException			lastException;

	/**
	 * True if the task were started but not completed.
	 */
	private boolean					taskRunning;

	/**
	 * Ctor
	 */
	public Task( )
	{
		this.listeners = new ArrayList<TaskListener>( );
		this.lastException = null;
		this.taskRunning = false;
	}

	/**
	 * Returns true if this task can be interrupted, false otherwise.
	 * @return
	 */
	public abstract boolean canCancelTask( );

	/**
	 * Returns true if during the execution of the task valid progress-informations will be generated via fireProgressUpdate(). In this case
	 * a progress-bar can be used to display the progress of the task. Otherwise the progress-bar should be used in intermediate-mode to
	 * visualize a heart beat of the running task
	 * @return
	 */
	public boolean hasValidProgressInformation( )
	{
		return true;
	}

	/**
	 * Returns the most recently exception occurred during the execution of the task or null if none was thrown.
	 * @return
	 */
	public TaskException getLastTaskException( )
	{
		return this.lastException;
	}

	/**
	 * Used for GUI purposes. Can be used to specify the color of a widget (e.g. progressbar) used to visualize the progress of the task.
	 * @return
	 */
	public Color getDefaultProgressBarColor( )
	{
		return new Color( 140, 185, 230 );
	}

	/**
	 * Add a new listener
	 * @param listener
	 */
	public void addListener( TaskListener listener )
	{
		this.listeners.add( listener );
	}

	/**
	 * Removes the specified listener
	 * @param listener
	 */
	public void removeListener( TaskListener listener )
	{
		this.listeners.remove( listener );
	}

	/**
	 * Notify all listeners that the job is completed.
	 */
	protected void fireTaskDone( )
	{
		while ( this.taskRunning || !this.isDone( ) )
		{
			try
			{
				Thread.sleep( 1 );
				System.err.println( "[" + System.identityHashCode( this ) + "] Task is waiting for being able to send the done-event to its listeners." );
			}
			catch ( InterruptedException e )
			{}
		}
		for ( TaskListener listener : this.listeners )
			listener.taskDone( this );

	}

	/**
	 * Notifies all listeners that the task was started
	 */
	protected void fireTaskStarted( )
	{
		while ( this.getState( ) == StateValue.PENDING )
		{
			try
			{
				Thread.sleep( 1 );
				if ( this.isCancelled( ) )
				{
					System.err.println( "[" + System.identityHashCode( this ) + "] Task that should be started was already cancelled." );
				}
				System.err.println( "[" + System.identityHashCode( this ) + "] Task is waiting for being able to send the start-event to its listeners." );
			}
			catch ( InterruptedException e )
			{}
		}
		for ( TaskListener listener : this.listeners )
			listener.taskStarted( this );

	}

	/**
	 * Notifies all listeners that the task was cancelled.
	 */
	protected void fireTaskCancelled( )
	{
		while ( this.taskRunning || !this.isDone( ) )
		{
			try
			{
				Thread.sleep( 1 );
				System.err.println( "[" + System.identityHashCode( this ) + "] Task is waiting for being able to send the cancel-event to its listeners." );
			}
			catch ( InterruptedException e )
			{}
		}
		for ( TaskListener listener : this.listeners )
			listener.taskCancelled( this );
	}

	/**
	 * Sends informations about the task progress to the attached listeners.
	 * @param progressInfo
	 */
	protected void fireProgressUpdate( ProgressInformation progressInfo )
	{
		setProgress( progressInfo.getProgress( ) );
		for ( TaskListener listener : listeners )
			listener.progressUpdate( progressInfo );
		try
		{
			Thread.sleep( 1 );
		}
		catch ( InterruptedException e )
		{}
	}

	/**
	 * This function returns the text which is used to represent the functionality of the task. The function have to be implemented.
	 * @return
	 */
	public abstract String getInformationText( );

	/**
	 * This function is called before the task will be started, so it is possible to do some stuff to initialize the task. The function have
	 * to be implemented.
	 */
	public abstract void initiate( );

	/**
	 * This function will be called when the Task is done or was canceled using the method kill(). So this method can be seen as a
	 * destructor within you are able to clean up or free the resources occupied by the Task.
	 */
	public abstract void dispose( );

	/**
	 * In this function the tasks functionality have to be implemented. Take care that the function have to set the progress to 100 via
	 * fireProgressUpdate( 100 ). to complete the work done in this task and to avoid an endless loop. Take care to request if the task were
	 * cancelled (via isCancelled()) and interrupt working in that case.
	 */
	protected abstract void work( ) throws TaskException;

	/**
	 * Use this function to kill/ cancel the Task.
	 */
	public void kill( )
	{

		// thread was already completed and don't have to be killed
		if ( this.getState( ) == StateValue.DONE )
			return;

		// waiting for thread leaving it's pneding-state and entering
		// the started-state
		while ( this.getState( ) == StateValue.PENDING )
		{
			try
			{
				Thread.sleep( 1 );
			}
			catch ( InterruptedException e )
			{}
		}

		// wait until the thread is really initated and started
		while ( !this.taskRunning )
		{
			try
			{
				Thread.sleep( 1 );
			}
			catch ( InterruptedException e )
			{}
		}

		// trying to cancel the thread until it's successful
		while ( ( this.cancel( true ) && !this.isCancelled( ) ) || !this.isDone( ) )
		{
			try
			{
				Thread.sleep( 1 );
			}
			catch ( InterruptedException e )
			{}
		}

	}

	/**
	 * Returns true if the task is running (was started but not completed yet).
	 * @return
	 */
	public boolean isTaskRunning( )
	{
		return this.taskRunning;
	}

	@Override
	protected Void doInBackground( ) throws Exception
	{
		try
		{
			synchronized ( this )
			{

				initiate( );
				fireTaskStarted( );
				this.taskRunning = true;
			}
			// do the work
			work( );
		}
		catch ( TaskException taskException )
		{
			this.lastException = taskException;
			if ( !this.isCancelled( ) )
				this.cancel( true );
		}
		catch ( Exception e )
		{
			String details = e.getLocalizedMessage( );
			/* add the stack-trace to the details */
			if ( details == null || details.trim( ).equals( "" ) )
			{
				details = "Stacktrace:\n ";
				for ( StackTraceElement s : e.getStackTrace( ) )
					details += s.toString( ) + "\n";
			}

			this.lastException = new TaskException( e.toString( ), details );
			if ( !this.isCancelled( ) )
				this.cancel( true );
			//			e.printStackTrace( );

		}

		synchronized ( this )
		{
			this.taskRunning = false;
			return null;
		}
	}

	@Override
	protected void done( )
	{
		// wait until the doInBackground-method is left
		while ( this.taskRunning )
		{
			try
			{
				Thread.sleep( 10 );
			}
			catch ( InterruptedException e )
			{}
		}

		this.dispose( );
		if ( this.isCancelled( ) )
			this.fireTaskCancelled( );
		else this.fireTaskDone( );

	}

}
