/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.messagePanel;

/**
 * @author Thomas Obenaus
 * @source MessageCategory.java
 * @date 12.08.2009
 */
public enum MessageCategory
{
	ERROR, INFO, WARNING;
}


