/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.task;

/**
 * @author Thomas Obenaus
 * @source MessagesDefaultTaskDialog.java
 * @date 27.10.2008
 */
public class MessagesDefaultTaskDialog extends MessagesTaskDialog
{
	public String	button_ok_tooltip	= "Ok";
	public String	button_ok_txt		= "Ok";

}


