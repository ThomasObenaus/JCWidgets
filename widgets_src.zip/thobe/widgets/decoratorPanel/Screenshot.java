/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.decoratorPanel;

import java.awt.Image;

/**
 * An interface whose instances of its implementing classes are able to offer an screenshot. 
 * @author Thomas Obenaus
 * @source Screenshot.java
 * @date 27.01.2012
 */
public interface Screenshot
{
	/**
	 * Returns a screenshot as {@link Image}
	 * @return
	 */
	public Image getScreenshot( );
}
