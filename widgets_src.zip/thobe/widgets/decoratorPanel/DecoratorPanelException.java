/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.decoratorPanel;

/**
 * @author Thomas Obenaus
 * @source DecoratorPanelException.java
 * @date 06.02.2012
 */
@SuppressWarnings ( "serial")
public class DecoratorPanelException extends Exception
{
	public DecoratorPanelException(String cause)
	{
		super(cause);
	}
}
