/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source RestrictedTextfieldListener.java
 * @date 20 Jun 2008
 */
public interface RestrictedTextfieldListener
{
	/**
	 * Called whenever the content of the textfield was modified and this modification was commited by pressing enter or by loosing the focus.
	 */
	public void valueChangeCommitted( );
	
	/**
	 * Called whenever the content of the textfield was modified during a keypress.
	 *
	 */
	public void valueChanged( );
	
	public void valueInvalid( String value );

	public void valueOutOfBounds( String value );
}


