/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;




/**
 * @author Thomas Obenaus
 * @source RestrictedTextFieldInteger.java
 * @date 12 Jun 2008
 */
/**
 * Represents an implementation of the RestrictedTextfield accepting only integer-values.
 */
public class RestrictedTextFieldInteger extends RestrictedTextfield<Integer>
{
	
	public RestrictedTextFieldInteger( boolean correctErrorOnCommit )
	{
		super( correctErrorOnCommit );
	}
	
	@Override
	protected Integer getDefaultValue( )
	{
		return 1;
	}
	

	@Override
	protected Integer convertStringToType( String stringToConvert ) throws ConvertException, InvalidValueExeption
	{
		try
		{
			return Integer.parseInt( stringToConvert );
		} 
		catch ( NumberFormatException e )
		{
			throw new ConvertException( stringToConvert, "Integer" );
		}
	}

	@Override
	protected String convertTypeToString( Integer typeToConvert )
	{
		return "" + typeToConvert;
	}

	@Override
	protected int compareValues( Integer val1, Integer val2 )
	{
		if( val1 > val2 ) return 1;
		if( val1 < val2 ) return -1;
		return 0;
	}
	

}


