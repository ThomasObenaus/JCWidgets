/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source RestrictedTextFieldMessages.java
 * @date 01.12.2009
 */
public interface RestrictedTextFieldMessageBuilder
{
	public String createRangeExceptionMsg( boolean lowerBoundExeeded, String exeededBound );

	public String createConvertExceptionMsg( String valueToConvert, String targetType );

	public String createInvalidValueExceptionMsg( String valueToConvert, String errorMessage );
}


