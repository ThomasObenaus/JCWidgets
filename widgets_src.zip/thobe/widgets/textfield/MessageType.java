/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source MessageState.java
 * @date 30.06.2009
 */
public enum MessageType
{
	ERROR, WARNING, INFO, NONE;
}


