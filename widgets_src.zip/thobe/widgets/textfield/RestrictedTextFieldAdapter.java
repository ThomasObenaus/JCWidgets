/*
 *  Copyright (C) 2013, Thomas Obenaus. All rights reserved.
 *  Licensed under the New BSD License (3-clause lic)
 *  See attached license-file.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		obenaus.thomas@gmail.com
 *  Project:    JavaComponents/Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source RestrictedTextFieldAdapter.java
 * @date 23.07.2009
 */
public class RestrictedTextFieldAdapter implements RestrictedTextfieldListener
{

	@Override
	public void valueChangeCommitted( )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void valueChanged( )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void valueInvalid( String value )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void valueOutOfBounds( String value )
	{
		// TODO Auto-generated method stub

	}

}
