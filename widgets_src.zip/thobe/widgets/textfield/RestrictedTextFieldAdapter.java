/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source RestrictedTextFieldAdapter.java
 * @date 23.07.2009
 */
public class RestrictedTextFieldAdapter implements RestrictedTextfieldListener
{

	@Override
	public void valueChangeCommitted( )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void valueChanged( )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void valueInvalid( String value )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void valueOutOfBounds( String value )
	{
		// TODO Auto-generated method stub

	}

}


