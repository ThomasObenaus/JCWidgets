/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source ConvertException.java
 * @date 23.11.2008
 */
public class ConvertException extends Exception
{
	private String	valueToConvert;
	private String	targetType;

	public ConvertException( String valueToConvert, String targetType )
	{	
		super( "Can't convert " + valueToConvert + " to " + targetType );
		this.targetType = targetType;
		this.valueToConvert = valueToConvert;
	}

	public String getValueToConvert( )
	{
		return valueToConvert;
	}

	public String getTargetType( )
	{
		return targetType;
	}
}


