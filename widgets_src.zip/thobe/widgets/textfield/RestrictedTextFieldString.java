/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;


/**
 * @author Thomas Obenaus
 * @source RestrictedTextFieldString.java
 * @date 7 Jul 2008
 */
/**
 * Represents an implementation of the RestrictedTextfield accepting all strings.
 */
public class RestrictedTextFieldString extends RestrictedTextfield<String>
{
	public RestrictedTextFieldString( boolean correctErrorOnCommit )
	{
		super( correctErrorOnCommit );
	}

	public RestrictedTextFieldString( int columns, boolean correctErrorOnCommit )
	{
		super( columns, correctErrorOnCommit );
	}

	@Override
	protected String convertStringToType( String stringToConvert ) throws ConvertException, InvalidValueExeption
	{
		return stringToConvert;
	}

	@Override
	protected String convertTypeToString( String typeToConvert )
	{
		return typeToConvert;
	}

	@Override
	protected int compareValues( String val1, String val2 )
	{
		if( val1.compareTo( val2 ) > 0 ) return 1;
		if( val1.compareTo( val2 ) < 0 ) return -1;
		return 0;
	}

	@Override
	protected String getDefaultValue( )
	{
		return "";
	}
}
