/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.textfield;

/**
 * @author Thomas Obenaus
 * @source InvalidValueExeption.java
 * @date 01.09.2010
 */
public class InvalidValueExeption extends Exception
{
	private String	valueToConvert;
	private String	message;

	public InvalidValueExeption( String valueToConvert, String message )
	{
		super( "The value " + valueToConvert + " is not allowed: " + message );
		this.message = message;
		this.valueToConvert = valueToConvert;
	}

	public String getValueToConvert( )
	{
		return valueToConvert;
	}

	public String getErrorMessage( )
	{
		return message;
	}
}


