/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.segmenteditor;

/**
 * @author Thomas Obenaus
 * @source Segment.java
 * @date 12.10.2012
 */
public class Segment

{
	private double	start;
	private double	end;
	private int		steps;

	public Segment( double start, double end, int steps )
	{
		super( );
		this.start = start;
		this.end = end;
		this.steps = steps;
	}

	public double getStart( )
	{
		return start;
	}

	public void setStart( double start )
	{
		this.start = start;
	}

	public double getEnd( )
	{
		return end;
	}

	public void setEnd( double end )
	{
		this.end = end;
	}

	public double getLength( )
	{
		return this.end - this.start;
	}

	public int getSteps( )
	{
		return steps;
	}

	public void setSteps( int steps )
	{
		this.steps = steps;
	}

}
