/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.segmenteditor;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

/**
 * @author Xuehao Wang
 * @source SegmentEditor.java
 * @date 12.10.2012
 */
public class SegmentEditor extends JPanel
{
	/**
	 * 
	 */
	private static final long			serialVersionUID	= 1L;
	private List<Segment>				segments;
	private List<SegmentEditorListener>	listeners;
	private List<Rectangle2D.Double>	rectList;
	private Point2D.Double				beginnPoint;
	private int							rectHight;
	private int							totalLength;
	private double						summeOfSegments;
	/**
	 * Index: -1 for inactive, otherwise the relevant element is activ for the paint() method activ.
	 */
	private int							selectedSegmentIndex;
	private int							dndIndex;
	private int							mouseOverIndex;
	private int							moveToIndex;
	private int							moveFromIndex;
	private Segment						toBeMovedSegment;
	private int							minWidth;
	private Rectangle2D.Double			moveShape;
	

	/**
	 * Constructor
	 * @param segments: List of Segments, which should be displayed
	 * @param minWidth: the minimal Width, that can be displayed
	 * @param hight: the hight of the Rect
	 */
	public SegmentEditor( List<Segment> segments, int minWidth, int height )
	{
		this.segments = segments;
		this.minWidth = minWidth;
		this.listeners = new ArrayList<>( );
		this.rectList = new ArrayList<>( );
		this.rectHight = height;
		/**
		 * the Origin of the Rect.
		 */
		this.beginnPoint = new Point2D.Double( 0, 0 );

		/**
		 * Initialization all of the Indexs to -1
		 */
		this.selectedSegmentIndex = -1;
		this.dndIndex = -1;
		this.mouseOverIndex = -1;
		this.moveToIndex = -1;
		this.moveFromIndex = -1;

		/**
		 * add the Listeners
		 */
		this.addMouseListener( new Mlistener( this ) );
		this.addMouseMotionListener( new MMlistener( this ) );
		this.addComponentListener( new Clistener( this ) );
		this.addKeyListener( new Klistener( this ) );
		this.setFocusable( true );
	}
	

	public void addListener(SegmentEditorListener listener)
	{
		this.listeners.add(listener);
	}
	
	public void removeListener(SegmentEditorListener listener)
	{
		this.listeners.remove(listener);
	}

	@Override
	@Transient
	public Dimension getPreferredSize( )
	{
		return new Dimension( this.minWidth, this.rectHight );
	}

	@Override
	@Transient
	public Dimension getMinimumSize( )
	{
		return new Dimension( this.minWidth, this.rectHight );
	}

	/**
	 * segment2Rect:
	 * <p>
	 * Calculate the length of each Rect for each Segment,<br>
	 * then save the Rect in a List, which can be used in this Class.
	 * </p>
	 */
	public void segment2Rect( )
	{
		summeOfSegments = 0;
		double positionX = this.beginnPoint.x;
		double positionY = this.beginnPoint.y;

		for ( Segment s : segments )
		{
			summeOfSegments += s.getLength( );
		}
		double proportion = totalLength / summeOfSegments;

		for ( int i = 0; i < segments.size( ); i++ )
		{
			double length = segments.get( i ).getLength( ) * proportion;
			if ( i > rectList.size( ) - 1 )
				this.rectList.add( new Rectangle2D.Double( positionX, positionY, length, ( double ) rectHight ) );
			else
				this.rectList.get( i ).setRect( positionX, positionY, length, ( double ) rectHight );
			positionX += length;
		}
	}

	/**
	 * rect2Segement:
	 * <p>
	 * rebuild the the ArrayList "segments", after the rectList <br>
	 * has been changed by the user.
	 * </p>
	 */
	public void rect2Segment( )
	{
		double proportion = summeOfSegments / totalLength;

		for ( int i = 0; i < segments.size( ); i++ )
		{
			/* former code
			segments.get( i ).setStart( rectList.get( i ).x * proportion );
			segments.get( i ).setEnd( ( rectList.get( i ).x + rectList.get( i ).width ) * proportion );
			*/
			
			if(i==0)
				segments.get( i ).setStart( 0 );
			else
				segments.get( i ).setStart( segments.get( i-1 ).getEnd( ) );
			
			double sum = scaleSafeAdd( rectList.get( i ).x, rectList.get( i ).width );
			segments.get( i ).setEnd( scaleSafeMultiply( sum, proportion ) );
		}
	}
	private static double scaleSafeAdd( double d1, double d2 )
	{
		int maxScale = Math.max( getScale( d1 ), getScale( d2 ) );
		double ret = d1 + d2;
		
		if( getScale( ret ) > maxScale )
			// is this really safe??
			ret = Math.round( ret * Math.pow( 10, maxScale ) ) / Math.pow( 10, maxScale );
		
		return ret;
	}
	private static double scaleSafeMultiply( double d1, double d2 )
	{
		int maxScale = getScale( d1 ) + getScale( d2 );
		double ret = d1 * d2;
		
		if( getScale( ret ) > maxScale )
			// is this really safe??
			ret = Math.round( ret * Math.pow( 10, maxScale ) ) / Math.pow( 10, maxScale );
		
		return ret;
	}
	private static int getScale( double d )
	{
		if( Double.isNaN( d ) || Double.isInfinite( d ) )
			return -1;
		
		String dbl = Double.toString( d );
		dbl = dbl.substring( dbl.indexOf( '.' )+1 );
		
		if( dbl.equals( "0" ))
			return 0;
		else
			return dbl.length();
	}

	/**
	 * refresh:
	 * <p>
	 * this method will be called, when either the "totalLength" or "segments"<br>
	 * has been changed. this method will recalculate the Rect for each Segment.
	 * </p>
	 */
	public void refresh( )
	{
		this.totalLength = this.getWidth( );
		this.segment2Rect( );
		this.repaint( );
	}

	public void paint( Graphics graphics )
	{
		/**
		 * clear the panel first
		 */
		super.paint( graphics );

		/**
		 * define the beginn point(left top)
		 */
		double positionX = beginnPoint.x;
		double positionY = beginnPoint.y;

		Rectangle2D.Double selectRect;

		Graphics2D g2 = ( Graphics2D ) graphics;

		/**
		 * go through the rectList
		 */
		for ( int i = 0; i < rectList.size( ); i++ )
		{
			/**
			 * Calculate the length of every step
			 */
			double stepLength = rectList.get( i ).width / segments.get( i ).getSteps( );
			/**
			 * for each step of Segment draw a rect on the panel
			 */
			for ( int j = 0; j < segments.get( i ).getSteps( ); j++ )
			{
				Rectangle2D.Double rect = new Rectangle2D.Double( positionX, positionY, stepLength, ( double ) rectHight );
				g2.draw( rect );
				/**
				 * for the even index of the Segment, set the background color to lightGray
				 */
				if ( i % 2 != 0 )
				{
					g2.setColor( Color.lightGray );
					g2.fill( rect );
					g2.setColor( Color.black );
					g2.draw( rect );
				}
				/**
				 * when mouseover set the Background color to cyan
				 */
				if ( mouseOverIndex != -1 && i == mouseOverIndex )
				{
					g2.setColor( Color.CYAN );
					g2.fill( rect );
					g2.setColor( Color.black );
					g2.draw( rect );
				}
				/**
				 * prepare to draw the next rect for next step
				 */
				positionX += stepLength;
			}
			
			/* DEBUG: print the start, end and length data over the full rectangle */
				Segment seg = segments.get( i );
				String posData = seg.getStart() +"->" +seg.getEnd() +"=" +seg.getLength();
				Rectangle2D.Double fullRect = rectList.get( i );
				float Y = fullRect.getBounds( ).y +fullRect.getBounds( ).height/2;
				Color tmp = g2.getColor( );
				g2.setColor( Color.RED );
				g2.drawString( posData, fullRect.getBounds( ).x +2, Y );
				g2.setColor( tmp );
			//*/
		}
		/**
		 * when the rect is selected, set the Weights of Bounder to 2 with color blue
		 */
		if ( selectedSegmentIndex != -1 )
		{
			g2.setColor( Color.BLUE );
			selectRect = rectList.get( selectedSegmentIndex );
			g2.setStroke( new BasicStroke( 2.0f ) );
			g2.draw( selectRect );
			g2.setColor( Color.BLACK );
			g2.setStroke( new BasicStroke( ) );
		}

		/**
		 * when a Rect is being draged to somewhere else, draw a little rect accompany the mouse
		 * CURSOR and mark the place with a black Line, where the draged rect will be placed
		 */
		if ( moveToIndex != -1 )
		{
			if ( moveShape != null )
			{
				float dash[] =
				{ 0.2f };
				g2.setStroke( new BasicStroke( 2.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 10.0f, dash, 0f ) );
				g2.draw( moveShape );
			}
			g2.setStroke( new BasicStroke( 3.0f ) );
			if ( moveToIndex != rectList.size( ) )
			{
				Line2D.Double moveToLine = new Line2D.Double( rectList.get( moveToIndex ).x, rectList.get( moveToIndex ).y, rectList.get( moveToIndex ).x, rectList.get( moveToIndex ).y + rectList.get( moveToIndex ).height );
				g2.draw( moveToLine );

			}
			else
			{
				Line2D.Double moveToLine = new Line2D.Double( rectList.get( moveToIndex - 1 ).x + rectList.get( moveToIndex - 1 ).width, rectList.get( moveToIndex - 1 ).y, rectList.get( moveToIndex - 1 ).x + rectList.get( moveToIndex - 1 ).width, rectList.get( moveToIndex - 1 ).y + rectList.get( moveToIndex - 1 ).height );
				g2.draw( moveToLine );
			}
			g2.setStroke( new BasicStroke( ) );
		}
		/**
		 * draw the Axis for the percent
		 */
		final double pointerLen = 10;
		Line2D.Double pointer0 = new Line2D.Double( 0, this.rectHight-pointerLen, 0, this.rectHight );
		Line2D.Double pointer1 = new Line2D.Double( totalLength * 0.25, this.rectHight-pointerLen, totalLength * 0.25, this.rectHight );
		Line2D.Double pointer2 = new Line2D.Double( totalLength * 0.5, this.rectHight-pointerLen, totalLength * 0.5, this.rectHight );
		Line2D.Double pointer3 = new Line2D.Double( totalLength * 0.75, this.rectHight-pointerLen, totalLength * 0.75, this.rectHight );
		Line2D.Double pointer4 = new Line2D.Double( totalLength, this.rectHight-pointerLen, totalLength, this.rectHight );
		
		Color colorNow = g2.getColor( );
		Font fontNow = g2.getFont( );
		g2.setColor( Color.MAGENTA );
		g2.setFont( fontNow.deriveFont( fontNow.getStyle( ) | Font.BOLD, fontNow.getSize( )*1.2f ) );
		g2.draw( pointer0 );
		//       g2.drawString( "0", 0, (float)(rectHight-pointerLen-5) );
		g2.draw( pointer1 );
		g2.drawString( "25%", ( float ) ( totalLength * 0.25 - 10 ), (float)(rectHight-pointerLen-5) );
		g2.draw( pointer2 );
		g2.drawString( "50%", ( float ) ( totalLength * 0.5 - 10 ), (float)(rectHight-pointerLen-5) );
		g2.draw( pointer3 );
		g2.drawString( "75%", ( float ) ( totalLength * 0.75 - 10 ), (float)(rectHight-pointerLen-5) );
		g2.draw( pointer4 );
		//       g2.drawString( "100%", (float)(totalLength-10), (float)(rectHight-pointerLen-5) );
		g2.setColor( colorNow );
		g2.setFont( fontNow );
	}

	public void addSegment( Segment s )
	{
		this.segments.add( s );
		this.refresh( );
	}

	public void addSegment( Segment s, int at )
	{
		this.segments.add( at, s );
		this.refresh( );
	}

	public Segment getSegment( int at )
	{
		return this.segments.get( at );
	}

	public int getSegmentCount()
	{
		return this.segments.size( );
	}
	
	/**
	 * Removes the segment, its representing rectangle and the current selection (if any).
	 */
	public void removeSegment( int at )
	{
		// deselect any rectangle
		this.selectedSegmentIndex = -1;

		this.segments.remove( at );
		
		// also remove corresponding rect
		this.rectList.remove( at );
		
		this.refresh( );
	}

	public void removeSegment( Segment s )
	{
		this.segments.remove( s );
		this.refresh( );
	}

	protected void fireOnLengthChanged( Segment changed, Segment collateral )
	{
		for ( SegmentEditorListener l : this.listeners )
			l.onLengthChanged( changed, collateral );
	}

	protected void fireOnSelected( Segment selected )
	{
		this.requestFocusInWindow( );
		
		for ( SegmentEditorListener l : this.listeners )
			l.onSelected( selected );
	}
	
	protected void fireOnRemoved( Segment selected )
	{
		for ( SegmentEditorListener l : this.listeners )
			l.onRemoved( selected );
	}
	
	protected void fireOnMoved( Segment segment, int newIdx)
	{
		for ( SegmentEditorListener l : this.listeners )
			l.onMoved( segment, newIdx );
	}

	/**
	 * Class Mlistener: the Listener extends from MouseListener
	 * @author Xuehao Wang
	 */
	class Mlistener extends MouseAdapter
	{
		private SegmentEditor	sEditor;

		public Mlistener( SegmentEditor s )
		{
			this.sEditor = s;
		}

		/**
		 * when mouse pressed on a Rect, set the selectedSegmentIndex to the relevant index then
		 * call the repaint() method
		 */
		public void mousePressed( MouseEvent e )
		{
			Point2D.Double sourcePoint = new Point2D.Double( e.getX( ), e.getY( ) );
			for ( int i = 0; i < rectList.size( ); i++ )
			{
				// segment rectangle inner clicked -> user wants to select or drag
				if ( sourcePoint.x > rectList.get( i ).x + 5 && sourcePoint.x < rectList.get( i ).x + rectList.get( i ).width - 5 && sourcePoint.y > beginnPoint.y && sourcePoint.y < beginnPoint.y + rectHight )
				{
					sEditor.selectedSegmentIndex = i;
					sEditor.repaint( );
					break;
				}
				// space around a separator of two segment rectangles clicked -> user wants to change length
				else if ( sourcePoint.x > rectList.get( i ).x + rectList.get( i ).width - 5 && sourcePoint.x < rectList.get( i ).x + rectList.get( i ).width + 5 && sourcePoint.y > beginnPoint.y && sourcePoint.y < beginnPoint.y + rectHight && i != rectList.size( ) - 1 )
				{
					sEditor.dndIndex = i;
					sEditor.repaint( );
					break;
				}
				else
				{
					sEditor.selectedSegmentIndex = -1;
					sEditor.repaint( );
				}
			}
			
			if(sEditor.selectedSegmentIndex != -1) fireOnSelected(getSegment(sEditor.selectedSegmentIndex)); 
		}

		/**
		 * mouseReleased: reset the changed Index, then call the rect2Segment() to rebuild the
		 * segments, in case that the user change the Rect per mouse
		 */
		public void mouseReleased( MouseEvent e )
		{
			// save the toBeMovedSegment if move complete, so we can fire the onMoved event later (must be after rect2Segment)
			Segment moved = null;
			
			// segment move complete
			if ( sEditor.moveToIndex != -1 && sEditor.toBeMovedSegment != null )
			{
				moved = sEditor.toBeMovedSegment;
				
				sEditor.segments.add( sEditor.moveToIndex, sEditor.toBeMovedSegment );
				sEditor.toBeMovedSegment = null;
				sEditor.refresh( );
			}
			// segment move cancelled
			if ( sEditor.moveToIndex == -1 && sEditor.toBeMovedSegment != null )
			{
				sEditor.segments.add( sEditor.moveFromIndex, sEditor.toBeMovedSegment );
				sEditor.toBeMovedSegment = null;
				sEditor.refresh( );
			}
			sEditor.moveToIndex = -1;
			sEditor.dndIndex = -1;
			sEditor.moveShape = null;
			sEditor.rect2Segment( );
			
			if( moved != null )
				sEditor.fireOnMoved( moved, sEditor.segments.indexOf( moved ) );
		}
	}

	/**
	 * Class MMlistener:
	 * @author Xuehao Wang
	 */
	class MMlistener extends MouseMotionAdapter
	{
		private SegmentEditor	sEditor;

		public MMlistener( SegmentEditor s )
		{
			this.sEditor = s;
		}

		/**
		 * mouseMoved: mouseMoved handler, for the case mouse over a Rect, set the mouseOverIndex,
		 * for the case mouse over between two Rect, set the mouse Cursor:
		 */
		public void mouseMoved( MouseEvent e )
		{
			Point2D.Double sourcePoint = new Point2D.Double( e.getX( ), e.getY( ) );
			String toolTipString = new String( );
			sEditor.setToolTipText( null );
			for ( int i = 0; i < rectList.size( ); i++ )
			{
				if ( sourcePoint.x > rectList.get( i ).x + 5 && sourcePoint.x < rectList.get( i ).x + rectList.get( i ).width - 5 && sourcePoint.y > beginnPoint.y && sourcePoint.y < beginnPoint.y + rectHight )
				{
					sEditor.mouseOverIndex = i;
					sEditor.repaint( );
					toolTipString = "Segment" + String.valueOf( i ) + "\n" + " Start: " + String.valueOf( segments.get( i ).getStart( ) ) + "\n" + " End: " + String.valueOf( segments.get( i ).getEnd( ) ) + "\n" + " Steps: " + String.valueOf( segments.get( i ).getSteps( ) );
					sEditor.setToolTipText( toolTipString );
					break;
				}

				else if ( sourcePoint.x > rectList.get( i ).x + rectList.get( i ).width - 5 && sourcePoint.x < rectList.get( i ).x + rectList.get( i ).width + 5 && sourcePoint.y > beginnPoint.y && sourcePoint.y < beginnPoint.y + rectHight && i != rectList.size( ) - 1 )
				{
					sEditor.setCursor( Cursor.getPredefinedCursor( Cursor.E_RESIZE_CURSOR ) );
					sEditor.mouseOverIndex = -1;
					sEditor.repaint( );
					break;
				}

				else
				{
					sEditor.setCursor( Cursor.getPredefinedCursor( Cursor.DEFAULT_CURSOR ) );
					sEditor.mouseOverIndex = -1;
					sEditor.repaint( );

				}

			}

		}

		/**
		 * mouseDragged: handler for the mouseDragged.
		 */
		public void mouseDragged( MouseEvent e )
		{
			Rectangle2D.Double rectLink;
			Rectangle2D.Double rectRight;

			Point2D.Double ePoint = new Point2D.Double( e.getX( ), e.getY( ) );

			/**
			 * for the case, that man drag the between two Rect, change the size of two rect.
			 */
			if ( sEditor.dndIndex != -1 )
			{
				rectLink = sEditor.rectList.get( dndIndex );
				rectRight = sEditor.rectList.get( dndIndex + 1 );
				if ( e.getX( ) > rectLink.x + 20 && e.getX( ) < ( rectRight.x + rectRight.width - 20 ) )
				{
					rectLink.setRect( rectLink.x, rectLink.y, e.getX( ) - rectLink.x, rectLink.height );
					rectRight.setRect( e.getX( ), rectRight.y, rectRight.width - ( e.getX( ) - rectRight.x ), rectRight.height );
					sEditor.setCursor( Cursor.getPredefinedCursor( Cursor.E_RESIZE_CURSOR ) );
					sEditor.rect2Segment( );
					sEditor.repaint( );
					
					sEditor.fireOnLengthChanged( sEditor.getSegment( dndIndex ), sEditor.getSegment( dndIndex +1 ) );
				}
				else
				{
					sEditor.setCursor( Cursor.getPredefinedCursor( Cursor.WAIT_CURSOR ) );
				}
			}

			/**
			 * for the case, that man drag one of the Rects.
			 */
			if ( sEditor.mouseOverIndex != -1 || sEditor.moveToIndex != -1 )
			{
				/**
				 * save the to be moved Rect
				 */
				sEditor.moveFromIndex = sEditor.mouseOverIndex;

				/**
				 * delete the dragged rect
				 */
				if ( sEditor.moveToIndex == -1 )
				{
					sEditor.toBeMovedSegment = sEditor.segments.get( moveFromIndex );
					sEditor.removeSegment( moveFromIndex );
					sEditor.mouseOverIndex = -1;
					sEditor.selectedSegmentIndex = -1;
					sEditor.refresh( );
					sEditor.setCursor( Cursor.getPredefinedCursor( Cursor.HAND_CURSOR ) );
				}
				/**
				 * make a Shape, which will accompany the mouse cursor
				 */
				sEditor.moveShape = new Rectangle2D.Double( ePoint.x - 10, ePoint.y - 10, 20, 20 );

				/**
				 * set the Index, that mark the place where the dragged rect will be placed.
				 */
				for ( int i = 0; i < sEditor.rectList.size( ); i++ )
				{
					if ( rectList.get( i ).contains( ePoint ) && ePoint.x < rectList.get( i ).getCenterX( ) )
					{
						sEditor.moveToIndex = i;
						sEditor.repaint( );
						break;
					}
					else if ( rectList.get( i ).contains( ePoint ) && ePoint.x > rectList.get( i ).getCenterX( ) )
					{
						sEditor.moveToIndex = i + 1;
						sEditor.repaint( );
						break;
					}

				}
			}
		}
	}

	class Clistener extends ComponentAdapter
	{
		private SegmentEditor	sEditor;

		public Clistener( SegmentEditor s )
		{
			this.sEditor = s;
		}

		public void componentResized( ComponentEvent e )
		{
			sEditor.refresh( );
		}
	}

	/**
	 * Class Klistener
	 * @author xwang
	 */
	class Klistener extends KeyAdapter

	{
		private SegmentEditor	sEditor;

		public Klistener( SegmentEditor s )
		{
			this.sEditor = s;
		}

		/**
		 * keyPressed: when the Key "del" is pressed, delete the selected Rect.
		 */
		public void keyPressed( KeyEvent e )
		{
			if ( e.getKeyCode( ) == 127 && sEditor.selectedSegmentIndex != -1 )
			{
				if ( selectedSegmentIndex < sEditor.segments.size( ) )
				{
					Segment s = sEditor.getSegment(selectedSegmentIndex);
					sEditor.removeSegment( selectedSegmentIndex );
					sEditor.selectedSegmentIndex = -1;
					sEditor.refresh( );
					SegmentEditor.this.fireOnRemoved(s);
				}
			}

		}
	}
}
