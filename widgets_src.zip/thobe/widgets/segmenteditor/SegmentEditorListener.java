/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.segmenteditor;

/**
 * @author Thomas Obenaus
 * @source SegmentEditorListener.java
 * @date 12.10.2012
 */
public interface SegmentEditorListener
{
	public void onSelected( Segment s );

	public void onLengthChanged( Segment left, Segment right );
	
	public void onRemoved( Segment s );
	
	public void onMoved( Segment s, int newIdx );
}
