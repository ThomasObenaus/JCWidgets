/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.inputSlider;

/**
 * @author Thomas Obenaus
 * @source InputSliderListener.java
 * @date 18 Nov 2008
 */
/**
 * Listener that listens for events caused by the change of the value the input-slider points to.
 */
public interface InputSliderListener
{
	/**
	 * Called whenever the position of the slider or the value typed in the text-field has changed. 
	 */
	public void valueChanged();
}


