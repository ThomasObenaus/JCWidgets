/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.multiFramePanel.actions;

import thobe.widgets.action.AbstrAction;

/**
 * @author Thomas Obenaus
 * @source Action.java
 * @date 10.05.2010
 */
public class Action extends ActionComponent
{
	private AbstrAction	action;

	public Action( AbstrAction action )
	{
		this.action = action;
	}

	public AbstrAction getAbstrAction( )
	{
		return this.action;
	}

	@Override
	public String getDescription( )
	{
		return ( String ) this.action.getValue( AbstrAction.SHORT_DESCRIPTION );
	}

	@Override
	public Action getAction( )
	{
		return this;
	}

	@Override
	public ActionGroup getActionGroup( )
	{
		return null;
	}

	@Override
	public String getName( )
	{
		return ( String ) this.action.getValue( AbstrAction.NAME );
	}

}



