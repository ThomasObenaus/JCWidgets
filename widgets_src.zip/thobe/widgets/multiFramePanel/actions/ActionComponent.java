/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.multiFramePanel.actions;

/**
 * @author Thomas Obenaus
 * @source ActionComponent.java
 * @date 10.05.2010
 */
public abstract class ActionComponent
{
	public abstract String getName( );

	public abstract String getDescription( );

	public abstract Action getAction( );

	public abstract ActionGroup getActionGroup( );
}


