/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.multiFramePanel;

import java.awt.BorderLayout;
import java.awt.Component;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;

import thobe.widgets.multiFramePanel.actions.ActionComponent;

/**
 * @author Thomas Obenaus
 * @source EmptyVizComponent.java
 * @date 16.04.2010
 */
public class DefaultFrameComponent extends FrameComponent
{


	public DefaultFrameComponent()
	{
		super( "Default component", "An empty VizComponent used as example" );
	}

	public Component getContentComponent( )
	{
		JPanel pa_content = new JPanel( new BorderLayout( ) );
		pa_content.add( new JLabel( "DefaultFrameComponent" ) );
		return pa_content;
	}

	@Override
	protected List<ActionComponent> getActionComponents( )
	{
		return null;
	}

	@Override
	public int getMinHeight( )
	{
		return 30;
	}

	@Override
	public int getMinWidth( )
	{
		return 30;
	}
}


