/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.action;

import javax.swing.Icon;

/**
 * @author Thomas Obenaus
 * @source AbstrActionPropertyChangeListener.java
 * @date 07.05.2010
 */
public interface AbstrActionPropertyChangeListener
{
	public void onIconsChanged( Icon iconEnabled, Icon iconDisabled );

	public void onSelectionIconsChanged( Icon iconSelectEnabled, Icon iconSelectDisabled );
}


