/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.action;

import java.util.HashMap;

/**
 * @author Thomas Obenaus
 * @source ActionRegistry.java
 * @date 26.08.2009
 */
public class ActionRegistry
{
	private HashMap<String, AbstrAction>	registeredActions;
	private static ActionRegistry			instance	= null;

	private ActionRegistry()
	{
		this.registeredActions = new HashMap<String, AbstrAction>( );
	}

	public static ActionRegistry get( )
	{
		if ( instance == null ) instance = new ActionRegistry( );
		return instance;
	}

	public AbstrAction getAction( String key )
	{
		return this.registeredActions.get( key );
	}

	public void registerAction( AbstrAction action )
	{
		this.registeredActions.put( action.getActionKey( ), action );
	}
}

