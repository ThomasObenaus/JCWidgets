/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.mergedCellsTable;

import javax.swing.table.AbstractTableModel;

/**
 * @author Thomas Obenaus
 * @source MergedCellsTableModel.java
 * @date 10.09.2009
 */
public abstract class MergedCellsTableModel extends AbstractTableModel 
{
	public abstract int getRowSpan( int row, int column );

	public abstract int getColSpan( int row, int column );

	public int[] getObscuringCell( int row, int column )
	{
		if ( this.mergeColumns( row ) && column > 0 ) return new int[]
		{ row, 0 };

		for ( int c = 0; c <= column; c++ )
		{

			for ( int r = 0; r <= row; r++ )
			{
				boolean columTouched = false;
				boolean rowTouched = false;
				if ( c == column && r == row ) continue;
				int colSpan = this.getColSpan( r, c );
				int rowSpan = this.getRowSpan( r, c );
				if ( ( rowSpan + r >= ( row + 1 ) ) ) rowTouched = true;
				if ( ( colSpan + c >= ( column + 1 ) ) ) columTouched = true;

				if ( rowTouched && columTouched )
				{
					System.err.println( row + "," + column + " overlap by " + r + "," + c );
					return new int[]
					{ r, c };
				}
			}
		}

		return new int[]
		{ -1, -1 };
	}

	public abstract boolean mergeColumns( int row );

}

