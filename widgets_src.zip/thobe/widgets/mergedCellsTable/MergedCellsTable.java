/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.mergedCellsTable;

import javax.swing.JTable;

/**
 * @author Thomas Obenaus
 * @source MergedCellsTable.java
 * @date 10.09.2009
 */
public class MergedCellsTable extends JTable
{
	public MergedCellsTable( MergedCellsTableModel tableModel )
	{
		super( tableModel );
		this.setUI( new MergedCellsTableUI( ) );
		this.getTableHeader( ).setReorderingAllowed( false );
	}
}


