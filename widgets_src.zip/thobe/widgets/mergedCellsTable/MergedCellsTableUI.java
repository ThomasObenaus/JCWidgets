/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.mergedCellsTable;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicTableUI;
import javax.swing.table.TableCellRenderer;

/**
 * @author Thomas Obenaus
 * @source MergedCellsTableUI.java
 * @date 10.09.2009
 */
public class MergedCellsTableUI extends BasicTableUI
{

	public void paint( Graphics g, JComponent c )
	{
		Rectangle oldClipBounds = g.getClipBounds( );
		Rectangle clipBounds = new Rectangle( oldClipBounds );
		int tableWidth = table.getColumnModel( ).getTotalColumnWidth( );
		clipBounds.width = Math.min( clipBounds.width, tableWidth );
		g.setClip( clipBounds );

		int firstIndex = table.rowAtPoint( new Point( 0, clipBounds.y ) );
		int lastIndex = table.getRowCount( ) - 1;

		Rectangle rowRect = new Rectangle( 0, 0, tableWidth, table.getRowHeight( ) + table.getRowMargin( ) );
		rowRect.y = firstIndex * rowRect.height;

		for ( int index = firstIndex; index <= lastIndex; index++ )
		{
			//						if ( rowRect.intersects( clipBounds ) )
			paintRow( g, index );
			rowRect.y += rowRect.height;
		}
		g.setClip( oldClipBounds );
	}

	private void paintRow( Graphics g, int row )
	{
		Rectangle rect = g.getClipBounds( );
		boolean drawn = false;

		MergedCellsTableModel tableModel = ( MergedCellsTableModel ) table.getModel( );
		int numColumns = table.getColumnCount( );

		boolean mergeColumns = tableModel.mergeColumns( row );
		for ( int column = 0; column < numColumns; column++ )
		{

			int cellRow, cellColumn;
			int[] obscCell = tableModel.getObscuringCell( row, column );

			cellRow = row;
			cellColumn = column;
			if ( obscCell[0] != -1 && obscCell[1] != -1 )
			{
				/* don't draw a cell if it's not visible but the cell obscuring this cell */
				cellRow = obscCell[0];
				cellColumn = obscCell[1];
			}

			Rectangle cellRect = table.getCellRect( cellRow, cellColumn, true );

			int width = 0;
			int height = 0;

			int rowSpan = tableModel.getRowSpan( cellRow, cellColumn );
			int colSpan = tableModel.getColSpan( cellRow, cellColumn );

			if ( mergeColumns && cellColumn == 0 ) colSpan = tableModel.getColumnCount( );

			/* calculate the width and height of the cell regarding the column-/ and row-span */
			for ( int i = 0; i < rowSpan; i++ )
				height += table.getCellRect( cellRow + i, cellColumn, true ).height;

			for ( int i = 0; i < colSpan; i++ )
				width += table.getCellRect( cellRow, cellColumn + i, true ).width;

			cellRect = new Rectangle( cellRect.x, cellRect.y, width, height );

			if ( cellRect.intersects( rect ) )
			{
				drawn = true;
				paintCell( g, cellRect, cellRow, cellColumn );
			}
			else
			{
				if ( drawn ) break;
			}
		}

	}

	private void paintCell( Graphics g, Rectangle cellRect, int row, int column )
	{
		int spacingHeight = table.getRowMargin( );
		int spacingWidth = table.getColumnModel( ).getColumnMargin( );

		Color c = g.getColor( );
		g.setColor( table.getGridColor( ) );
		g.drawRect( cellRect.x, cellRect.y, cellRect.width, cellRect.height );
		g.setColor( c );

		cellRect.setBounds( cellRect.x + spacingWidth / 2, cellRect.y + spacingHeight / 2, cellRect.width - spacingWidth, cellRect.height - spacingHeight );

		if ( table.isEditing( ) && table.getEditingRow( ) == row && table.getEditingColumn( ) == column )
		{
			Component component = table.getEditorComponent( );
			component.setBounds( cellRect );
			component.validate( );
		}
		else
		{
			TableCellRenderer renderer = table.getCellRenderer( row, column );
			Component component = table.prepareRenderer( renderer, row, column );

			if ( component.getParent( ) == null )
			{
				rendererPane.add( component );
			}
			rendererPane.paintComponent( g, component, table, cellRect.x, cellRect.y, cellRect.width, cellRect.height, true );
		}
	}
}