/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.splitPanel;

/**
 * @author Thomas Obenaus
 * @source SPSubFrameXML.java
 * @date 10.07.2012
 */
public class SPSubFrameXML extends SPFrameXML
{
	private String	contentKey;

	public SPSubFrameXML( String contentKey )
	{
		this.contentKey = contentKey;
	}

	@Override
	public SPSubFrameXML asSubFrame( )
	{
		return this;
	}

	public String getContentKey( )
	{
		return contentKey;
	}

	@Override
	public String toString( )
	{
		return "SubF contentKey=" + this.contentKey;
	}
}
