/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.splitPanel;

/**
 * @author Thomas Obenaus
 * @source SPContentSwitchListener.java
 * @date 16.02.2012
 */
public interface SPContentSwitchListener
{
	public void onContentSwitch(String oldContentKey,String newContentKey);
}


