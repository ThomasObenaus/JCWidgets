/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.splitPanel;

/**
 * @author Thomas Obenaus
 * @source SplitPanelListener.java
 * @date 27.08.2012
 */
public interface SplitPanelListener
{
	/**
	 * Called whenever a specific {@link SPSubFrame} was clicked.
	 * @param event - the {@link SPSubFrameEvent}
	 */
	public void onSubFrameClicked( SPSubFrameEvent event );

	/**
	 * Called whenever the mouse has entered a specific {@link SPSubFrame}
	 * @param event - the {@link SPSubFrameEvent}
	 */
	public void onSubFrameEntered( SPSubFrameEvent event );

	/**
	 * Called whenever the mouse has left/exited a specific {@link SPSubFrame}
	 * @param event - the {@link SPSubFrameEvent}
	 */
	public void onSubFrameExited( SPSubFrameEvent event );

	public void onSubFrameRemoved( SPSubFrameEvent event );

	public void onSubFrameContentSwitched( SPSubFrameEvent event );
}
