/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.splitPanel;

/**
 * An enum representing the type of an {@link SPDivider}.
 * @author Thomas Obenaus
 * @source SPDividerType.java
 * @date 13.02.2012
 */
public enum SPDividerType
{
	VERTICAL, HORIZONTAL;
}
