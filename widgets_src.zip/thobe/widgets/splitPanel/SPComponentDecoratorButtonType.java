/*
 *  Copyright (C) 2013 ThObe. All rights reserved.
 *
 *	Author: 	Thomas Obenaus
 *	EMail:		ThomasObenaus@gmx.net
 *  Project:    JavaComponents - Widgets
 */
package thobe.widgets.splitPanel;

/**
 * Enumeration representing the different buttons of the {@link SPComponentDecorator}s top right menu-bar
 * @author Thomas Obenaus
 * @source SPComponentDecoratorButtonType.java
 * @date 14.02.2012
 */
public enum SPComponentDecoratorButtonType
{
	/**
	 * The close button.
	 */
	CLOSE,
	/**
	 * The maximize/ minimize button
	 */
	MAXIMIZE,
	/**
	 * The vertical-split button
	 */
	VSPLIT,
	/**
	 * The horizontal-split button
	 */
	HSPLIT;
}
